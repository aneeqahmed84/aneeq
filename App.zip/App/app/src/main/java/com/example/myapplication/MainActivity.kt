package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txt1 = findViewById<EditText>(R.id.item1)
        val qty1 = findViewById<EditText>(R.id.quantity1)
        val prc1 = findViewById<EditText>(R.id.price1)
        val qty2 = findViewById<EditText>(R.id.quantity2)
        val prc2 = findViewById<EditText>(R.id.price2)
        val qty3 = findViewById<EditText>(R.id.quantity3)
        val prc3 = findViewById<EditText>(R.id.price3)
        val btn = findViewById<Button>(R.id.calc)

        btn.setOnClickListener {
            var total = prc1.text.toString().toInt() * qty1.text.toString().toInt() + prc2.text.toString().toInt() * qty2.text.toString().toInt() + prc3.text.toString().toInt() * qty3.text.toString().toInt()
            val intent = Intent(this, MainActivity2::class.java)
            intent.putExtra("total", total.toString())
            startActivity(intent)
        }
    }
}